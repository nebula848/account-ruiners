# Jajaja-Account-Nuker
Account nuker, discord token fucker for discord.


![](https://github.com/xanthe1337/Jajaja-Account-Nuker/blob/master/images/W4VcGw.png?raw=true)

# Install chromedriver.exe
  - https://chromedriver.chromium.org/downloads


# Legality

Everything you can see here has been made for educational purposes and proof of concepts. I do not promote the usage of my tools, I do not take responsability on the bad usage of this tool.
