# Jajaja-Account-Nuker
Account nuker, discord token fucker for discord.


![](https://github.com/nebula848/account-ruiners)

# Install chromedriver.exe
  - https://chromedriver.chromium.org/downloads


# Legality

Everything you can see here has been made for educational purposes and proof of concepts. I do not promote the usage of my tools, I do not take responsability on the bad usage of this tool.
